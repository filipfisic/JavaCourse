# Evidencija Vozila

Jednostavan Java projekt za vođenje evidencije vozila (automobili i motocikli) uz rad s datotekama i obradom iznimki.

## Funkcionalnosti:
- Dodavanje vozila.
- Spremanje podataka u datoteku.
- Učitavanje podataka iz datoteke.
- Obrada grešaka (neispravni podaci).

## Pokretanje:
Pokrenuti `Main.java`.

## Napomena:
Projekt implementira nasljeđivanje, polimorfizam, rad s tekstualnim datotekama i vlastitu iznimku.