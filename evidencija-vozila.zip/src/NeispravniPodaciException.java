public class NeispravniPodaciException extends Exception {
    public NeispravniPodaciException(String poruka) {
        super(poruka);
    }
}